package ex11_1_exercise;

// import statements here:


public class ShoppingCart {
    public static void main(String[] args){
	// Declare a LocalDateTime object, orderDate

        
	// Initialize the orderDate to the current date and time. Print it.


	// Format orderDate using ISO_LOCAL_DATE; Print it.


    }
}