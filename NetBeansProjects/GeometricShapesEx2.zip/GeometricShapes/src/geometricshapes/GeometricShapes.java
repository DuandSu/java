/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricshapes;

/**
 *
 * @author Duane Munro
 * 
 * This is Assignment #2, Exercise #1.
 */
public class GeometricShapes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create my rectangle
        
        Rectangle myRectangle = new Rectangle ();
        
        myRectangle.length = 5.0;
        myRectangle.width = 10.0;
        
        // Calculate the Area of my rectangle.
        
        if (myRectangle.getArea()) {
            System.out.println("The Area of the Rectange with Lengh of " + myRectangle.length + " and Width of " + myRectangle.width + " is " + myRectangle.area);
        }
        else {
            System.out.println("There was a problem with the Rectangle Area calculation. Neither Length '" + myRectangle.length + "' or Width '" + myRectangle.width + "' can be 0.");
        }
        
        // Calculate the Perimeter of my rectangle.
        
        if (myRectangle.getPerimeter()) {
            System.out.println("The Perimeter of the Rectange with Lengh of " + myRectangle.length + " and Width of " + myRectangle.width + " is " + myRectangle.perimeter);
        }
        else {
            System.out.println("There was a problem with the Rectangle Perimeter calculation. Neither Length '" + myRectangle.length + "' or Width '" + myRectangle.width + "' can be 0.");
        }

        // Create my square
        
        Square mySquare = new Square ();
        
        mySquare.side = 10.0;
                
        // Calculate the Area of my square.
        
        if (mySquare.getArea()) {
            System.out.println("The Area of the Square with each Side of " + mySquare.side + " is " + mySquare.area);
        }
        else {
            System.out.println("There was a problem with the Square Area calculation. The Sides '" + mySquare.side + "' can NOT be 0.");
        }
        
        // Calculate the Perimeter of my square.
        
        if (mySquare.getPerimeter()) {
            System.out.println("The Perimeter of the Rectange with Lengh of " + mySquare.side + " is " + mySquare.perimeter);
        }
        else {
            System.out.println("There was a problem with the Square Perimeter calculation. The Sides '" + mySquare.side + "' can NOT be 0.");
        }

        // Create my circle
        
        Circle myCircle = new Circle ();
        
        myCircle.diameter = 10.0;
        //myCircle.radius = 5.0;
                
        // Calculate the Area of my circle.
        
        if (myCircle.getArea()) {
            System.out.println("The Area of the Circle with Diameter of " + myCircle.diameter + " and Radius of " + myCircle.radius + " is " + myCircle.area);
        }
        else {
            System.out.println("There was a problem with the Circle Area calculation. Diameter '" + myCircle.diameter + "' and Radius '" + myCircle.radius + "' can NOT both be 0.");
        }
        
        // Calculate the Perimeter of my circle.
        
        if (myCircle.getPerimeter()) {
             System.out.println("The Perimeter of the Circle with Diameter of " + myCircle.diameter + " and Raidus of " + myCircle.radius + " is " + myCircle.perimeter);
        }
        else {
            System.out.println("There was a problem with the Circle Perimeter calculation. Diameter '" + myCircle.diameter + "' and Radius '" + myCircle.radius + "' can NOT both be 0.");
        }
        // Create my rhombus
        
        Rhombus myRhombus = new Rhombus ();
        
        myRhombus.side = 5.0;
        myRhombus.pDiagonal = 10.0;
        myRhombus.qDiagonal = 10.0;
        
        // Calculate the Area of my rhombus.
        
        if (myRhombus.getArea()) {
            System.out.println("The Area of the Rhombus with pDiagonal of " + myRhombus.pDiagonal + " and qDiagonal of " + myRhombus.qDiagonal + " is " + myRhombus.area);
        }
        else {
            System.out.println("There was a problem with the Rhombus Area calculation. Neither pDiagonal '" + myRhombus.pDiagonal + "' or qDiagonal '" + myRhombus.qDiagonal + "' can be 0.");
        }
        
        // Calculate the Perimeter of my rhombus.
        
        if (myRhombus.getPerimeter()) {
            System.out.println("The Perimeter of the Rhombus with each Side of " + myRhombus.side + " is " + myRhombus.perimeter);
        }
        else {
            System.out.println("There was a problem with the Rhombus Perimeter calculation. The Sides '" + myRhombus.side + "' can NOT be 0.");
        }

    }
    
}
