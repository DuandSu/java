/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricshapes;

/**
 *
 * @author Duane
 * 
 * This Class represents the Rhombus Object.
 */
public class Rhombus {
    
    public double side;
    public double pDiagonal;
    public double qDiagonal;
    public double area;
    public double perimeter;
    
    //Constructor
    public Rhombus () {
        side = 0.0;
        pDiagonal = 0.0;
        qDiagonal = 0.0;
        area = 0.0;
        perimeter = 0.0;
    }
    
    //Methods
    
    
    // Calculate the area using the length and width
    
    public boolean getArea () {
        if (this.pDiagonal == 0.0 || this.qDiagonal == 0.0) {
            return false;
        }
        else {
            this.area = (this.pDiagonal * this.qDiagonal) / 2;
            return true;
        }
    }
    
    // Calculate the Perimeter using the sides
    
    public boolean getPerimeter () {
        if (this.side == 0.0) {
            return false;
        }
        else {
            this.perimeter = 4 * this.side;
            return true;
        }
    }
    
}
