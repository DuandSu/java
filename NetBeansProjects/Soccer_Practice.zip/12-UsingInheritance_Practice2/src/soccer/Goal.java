/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package soccer;

/**
 *
 * @author Duane Munro
 */

/* Practice 12-2. Make this class extend GameEvent */
public class Goal extends GameEvent {
    

    
}
