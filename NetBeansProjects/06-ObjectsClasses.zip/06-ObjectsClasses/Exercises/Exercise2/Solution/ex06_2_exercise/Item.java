
package ex06_2_exercise;

public class Item {

        public int itemID;
        public String desc;
        public double price;
        public int quantity;
        
}
