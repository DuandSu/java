Exercise 6-1

1. Create the Item class as a plain "Java class" in the package ex06_1_exercise.
2. Declare public fields for ID (int), descr (String),
    quantity (int), price (double).