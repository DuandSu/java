/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package soccer;

/**
 *
 * @author ksomervi
 */
public class Possession extends GameEvent {
    
    public String toString(){
        return "Possession";
    }
    
}
