Exercise 14-1

In the Calculator class:
1.  Change the divide method signature so that it throws 
      an ArithmeticException.

In the ShoppingCart class:
2.  Surround the code that calls the divide method
      with a try / catch block.  Handle the exception 
      object by printing it to the console.
3.  Run the ShoppingCart to view the outcome.