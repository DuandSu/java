Exercise 12-2

In the Shirt class:
1.  Override the display method and do the following:
	- Call the superclass's display method.
	- Print the size field and the colorCode field.  
2.  Run the ShoppingCart class.  Do you see a different 
      display than you did in the previous exercise?