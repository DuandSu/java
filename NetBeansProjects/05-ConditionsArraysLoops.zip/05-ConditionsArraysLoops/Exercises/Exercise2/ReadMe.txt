Exercise 5-2

1. Declare a String array and initialize it with 4 elements.
     Each element represents a different item description ("Shirt", for instance).
2. Change message to show how many items the customer wants to purchase 
     (Use the length property of the items array).
3. Print just one element of the items array.  
     What happens if you use index number 4?