
package ex04_2_exercise;

public class ShoppingCart {
    
    public static void main(String[] args) {
        String custName = "Mary Smith";
        String itemDesc = "Shirt";
        String message = custName+" wants to purchase a "+itemDesc;
        
        // Declare and initialize numeric fields: price, tax, quantity, and total.   
        
        
        // Modify message to include quantity 
        
        
        System.out.println(message);
        
        // Calculate total and then print the total cost
        

        
    }    
}
